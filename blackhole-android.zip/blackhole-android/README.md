# Чёрная дыра — Android приложение

Простая WebView-обёртка с 3D-симуляцией чёрной дыры (Three.js + WebGL).

## Самый простой способ — GitHub Actions (рекомендую)

Никакой Android Studio на твоём компе не нужна. GitHub сам скачает JDK, Android SDK, Gradle и соберёт APK.

### Шаги:

1. Создай **новый репозиторий** на GitHub (можно приватный).
2. Залей **всю содержимое** папки `blackhole-android` в **корень** репозитория  
   (через кнопку "Upload files" на GitHub или через `git`).
3. Перейди во вкладку **Actions**.
4. Слева выбери workflow **Build APK** → справа кнопка **Run workflow** → Run.
5. Подожди 2–5 минут (первый раз дольше, пока качает SDK).
6. Когда статус станет зелёным — внизу страницы будет раздел **Artifacts**.
7. Скачай `blackhole-apk` → внутри лежит `app-debug.apk`.
8. Перекинь APK на телефон и установи (может понадобиться разрешить установку из неизвестных источников).

Готово. Дальше при каждом пуше в main/master APK будет собираться автоматически.

## Альтернатива — Android Studio локально

1. Установи [Android Studio](https://developer.android.com/studio)
2. File → Open → выбери папку `blackhole-android`
3. Дождись синхронизации Gradle
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK появится в `app/build/outputs/apk/debug/`

## Что внутри

- Полноэкранный WebView
- Локальная HTML-симуляция (Three.js)
- Hardware acceleration для WebGL
- Иконки под разные плотности экрана
- GitHub Actions workflow уже настроен

## Требования

- minSdk 24 (Android 7.0+)
- OpenGL ES 2.0 (есть почти на всех телефонах)
